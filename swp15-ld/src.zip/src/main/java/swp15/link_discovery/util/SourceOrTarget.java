package swp15.link_discovery.util;

/**
 * Helper Enum to differentiate between Source and Target
 * 
 * @author Sascha Hahne
 *
 */
public enum SourceOrTarget {
	SOURCE, TARGET
}
